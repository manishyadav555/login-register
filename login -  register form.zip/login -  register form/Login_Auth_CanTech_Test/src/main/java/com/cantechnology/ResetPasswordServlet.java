package com.cantechnology;

import com.cantechnology.util.DBUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/reset")
public class ResetPasswordServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String token = request.getParameter("token");
        
        try (Connection conn = DBUtil.getConnection()) {
            String query = "SELECT user_id FROM password_reset_tokens WHERE token = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, token);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                request.setAttribute("token", token);
                request.getRequestDispatcher("/reset_password.jsp").forward(request, response);
            } else {
                response.getWriter().println("Invalid or expired token.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("An error occurred. Please try again later.");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String token = request.getParameter("token");
        String newPassword = request.getParameter("newPassword");
        
        try (Connection conn = DBUtil.getConnection()) {
            String query = "SELECT user_id FROM password_reset_tokens WHERE token = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, token);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                int userId = rs.getInt("user_id");
                
                String updatePasswordQuery = "UPDATE users SET password = ? WHERE id = ?";
                PreparedStatement updateStmt = conn.prepareStatement(updatePasswordQuery);
                updateStmt.setString(1, newPassword); // Make sure to hash the password in a real application
                updateStmt.setInt(2, userId);
                updateStmt.executeUpdate();
                
                String deleteTokenQuery = "DELETE FROM password_reset_tokens WHERE token = ?";
                PreparedStatement deleteStmt = conn.prepareStatement(deleteTokenQuery);
                deleteStmt.setString(1, token);
                deleteStmt.executeUpdate();
                
                response.getWriter().println("Password has been reset successfully.");
            } else {
                response.getWriter().println("Invalid or expired token.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("An error occurred. Please try again later.");
        }
    }
}
