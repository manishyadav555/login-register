package com.cantechnology;
import com.cantechnology.util.DBUtil;
import com.cantechnology.util.EmailUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;

@WebServlet("/forgot")
public class ForgotPasswordServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        
        try (Connection conn = DBUtil.getConnection()) {
            String query = "SELECT id FROM users WHERE email = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                int userId = rs.getInt("id");
                String token = UUID.randomUUID().toString();
                
                String insertTokenQuery = "INSERT INTO password_reset_tokens (user_id, token) VALUES (?, ?)";
                PreparedStatement insertStmt = conn.prepareStatement(insertTokenQuery);
                insertStmt.setInt(1, userId);
                insertStmt.setString(2, token);
                insertStmt.executeUpdate();
                
                String resetLink = "http://localhost:8080/reset-password?token=" + token;
                EmailUtil.sendEmail(email, "Password Reset Request", "Click here to reset your password: " + resetLink);
               
                response.getWriter().println("Password reset link sent to your email.");
            } else {
                response.getWriter().println("Email not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("An error occurred. Please try again later.");
        }
    }
}
